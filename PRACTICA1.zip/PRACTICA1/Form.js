function validarFormulario(){
    let x= document.forms["frm1"]["Nombre"].value;
if(x===""){
    alert("SE DEBE COMPLETAR EL NOMBRE");
    return false;
}
}